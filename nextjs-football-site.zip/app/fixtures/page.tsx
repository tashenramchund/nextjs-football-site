import { getUpcomingFixtures } from '@/lib/api'
import MatchCard from '@/components/MatchCard'
export default async function FixturesPage() {
  const fixtures = await getUpcomingFixtures({ limit: 200 })
  return (
    <section>
      <h1 className="text-2xl font-semibold mb-6">All upcoming fixtures</h1>
      <div className="grid gap-4">
        {fixtures.map((m) => <MatchCard key={m.id} match={m} />)}
      </div>
    </section>
  )
}
