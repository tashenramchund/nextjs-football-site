import { getFixturesByLeague } from '@/lib/api'
import MatchCard from '@/components/MatchCard'
interface Props { params: { league: string } }
export default async function LeaguePage({ params }: Props) {
  const fixtures = await getFixturesByLeague(params.league)
  return (
    <section>
      <h1 className="text-2xl font-bold mb-4">{params.league.toUpperCase()} — Fixtures</h1>
      <div className="grid gap-4">{fixtures.map(f => <MatchCard key={f.id} match={f} />)}</div>
    </section>
  )
}
export async function generateStaticParams() {
  return [{ league: 'premier-league' },{ league: 'la-liga' },{ league: 'champions-league' }]
}
