import Link from 'next/link'
import { getUpcomingFixtures } from '@/lib/api'
import MatchCard from '@/components/MatchCard'
export default async function Home() {
  const fixtures = await getUpcomingFixtures({ limit: 10 })
  return (
    <section>
      <h1 className="text-3xl font-bold mb-4">Upcoming Matches</h1>
      <div className="grid gap-4">
        {fixtures.map((m) => (<MatchCard key={m.id} match={m} />))}
      </div>
      <div className="mt-8">
        <Link href="/fixtures" className="underline">See full fixtures</Link>
      </div>
    </section>
  )
}
